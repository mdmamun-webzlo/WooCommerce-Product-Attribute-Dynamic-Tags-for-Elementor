<?php
/**
 * Plugin Name: Webzlo Elementor Product Attribute Tags
 * Description: Adds WooCommerce product attribute dynamic tags for Elementor Loop Grid/Product Templates.
 * Version: 1.0.0
 * Author: Md Mamun Miah - Webzlo
 * Author URI: https://webzlo.com/
 * Text Domain: webzlo-epa-tags
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Webzlo_Elementor_Product_Attribute_Tags {

    const VERSION = '1.0.0';

    public function __construct() {
        add_action( 'plugins_loaded', [ $this, 'init' ] );
    }

    public function init() {
        if ( ! did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', [ $this, 'elementor_missing_notice' ] );
            return;
        }

        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action( 'admin_notices', [ $this, 'woocommerce_missing_notice' ] );
            return;
        }

        add_action( 'elementor/dynamic_tags/register', [ $this, 'register_dynamic_tags' ] );
    }

    public function elementor_missing_notice() {
        echo '<div class="notice notice-warning"><p><strong>Webzlo Elementor Product Attribute Tags</strong> requires Elementor to be installed and active.</p></div>';
    }

    public function woocommerce_missing_notice() {
        echo '<div class="notice notice-warning"><p><strong>Webzlo Elementor Product Attribute Tags</strong> requires WooCommerce to be installed and active.</p></div>';
    }

    public function register_dynamic_tags( $dynamic_tags ) {
        require_once __DIR__ . '/includes/class-webzlo-product-attribute-tag.php';
        require_once __DIR__ . '/includes/class-webzlo-product-attribute-list-tag.php';

        if ( method_exists( $dynamic_tags, 'register_group' ) ) {
            $dynamic_tags->register_group( 'webzlo-woocommerce-attributes', [
                'title' => esc_html__( 'WooCommerce Product Attributes', 'webzlo-epa-tags' ),
            ] );
        }

        if ( method_exists( $dynamic_tags, 'register' ) ) {
            $dynamic_tags->register( new \Webzlo_Product_Attribute_Tag() );
            $dynamic_tags->register( new \Webzlo_Product_Attribute_List_Tag() );
        } else {
            $dynamic_tags->register_tag( 'Webzlo_Product_Attribute_Tag' );
            $dynamic_tags->register_tag( 'Webzlo_Product_Attribute_List_Tag' );
        }
    }
}

new Webzlo_Elementor_Product_Attribute_Tags();
