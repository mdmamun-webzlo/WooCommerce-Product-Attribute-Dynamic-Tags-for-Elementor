<?php
if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Core\DynamicTags\Tag;

class Webzlo_Product_Attribute_Tag extends Tag {

    public function get_name() {
        return 'webzlo-product-attribute';
    }

    public function get_title() {
        return esc_html__( 'Product Attribute', 'webzlo-epa-tags' );
    }

    public function get_group() {
        return 'webzlo-woocommerce-attributes';
    }

    public function get_categories() {
        return [
            \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
        ];
    }

    protected function register_controls() {
        $this->add_control( 'attribute_name', [
            'label' => esc_html__( 'Attribute', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::SELECT2,
            'options' => $this->get_attribute_options(),
            'label_block' => true,
        ] );

        $this->add_control( 'show_label', [
            'label' => esc_html__( 'Show Label', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Yes', 'webzlo-epa-tags' ),
            'label_off' => esc_html__( 'No', 'webzlo-epa-tags' ),
            'return_value' => 'yes',
            'default' => '',
        ] );

        $this->add_control( 'separator', [
            'label' => esc_html__( 'Label Separator', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::TEXT,
            'default' => ': ',
            'condition' => [ 'show_label' => 'yes' ],
        ] );

        $this->add_control( 'prefix', [
            'label' => esc_html__( 'Before', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::TEXT,
            'default' => '',
        ] );

        $this->add_control( 'suffix', [
            'label' => esc_html__( 'After', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::TEXT,
            'default' => '',
        ] );

        $this->add_control( 'empty_fallback', [
            'label' => esc_html__( 'Fallback if Empty', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::TEXT,
            'default' => '',
        ] );
    }

    private function get_product() {
        global $product;

        if ( $product instanceof WC_Product ) {
            return $product;
        }

        $post_id = get_the_ID();
        if ( $post_id ) {
            return wc_get_product( $post_id );
        }

        return false;
    }

    private function get_attribute_options() {
        $options = [];

        if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
            $taxonomies = wc_get_attribute_taxonomies();
            if ( ! empty( $taxonomies ) ) {
                foreach ( $taxonomies as $tax ) {
                    $slug = wc_attribute_taxonomy_name( $tax->attribute_name );
                    $options[ $slug ] = $tax->attribute_label . ' (' . $slug . ')';
                }
            }
        }

        $options['custom:pad.plotis'] = 'pad.plotis (custom)';
        $options['custom:pad.aukštis'] = 'pad.aukštis (custom)';
        $options['custom:pad.diametras'] = 'pad.diametras (custom)';
        $options['custom:season'] = 'season (custom)';
        $options['custom:kuras'] = 'kuras (custom)';
        $options['custom:triukšmas'] = 'triukšmas (custom)';
        $options['custom:shipping_time'] = 'shipping_time (custom)';

        return $options;
    }

    private function normalize_attribute_key( $key ) {
        $key = trim( (string) $key );
        if ( strpos( $key, 'custom:' ) === 0 ) {
            return substr( $key, 7 );
        }
        return $key;
    }

    private function get_attribute_label( $key ) {
        $raw_key = $this->normalize_attribute_key( $key );

        if ( taxonomy_exists( $raw_key ) ) {
            return wc_attribute_label( $raw_key );
        }

        return $raw_key;
    }

    private function get_attribute_value( $product, $key ) {
        $raw_key = $this->normalize_attribute_key( $key );

        $value = $product->get_attribute( $raw_key );

        if ( '' === $value && 0 !== strpos( $raw_key, 'pa_' ) ) {
            $value = $product->get_attribute( sanitize_title( $raw_key ) );
        }

        if ( '' === $value ) {
            $meta_keys = [ $raw_key, sanitize_title( $raw_key ), '_' . $raw_key, '_' . sanitize_title( $raw_key ) ];
            foreach ( $meta_keys as $meta_key ) {
                $meta_value = get_post_meta( $product->get_id(), $meta_key, true );
                if ( '' !== $meta_value && null !== $meta_value ) {
                    if ( is_array( $meta_value ) ) {
                        $meta_value = implode( ', ', array_filter( array_map( 'wc_clean', $meta_value ) ) );
                    }
                    return wp_strip_all_tags( (string) $meta_value );
                }
            }
        }

        return wp_strip_all_tags( (string) $value );
    }

    public function render() {
        $settings = $this->get_settings();
        $attribute = ! empty( $settings['attribute_name'] ) ? $settings['attribute_name'] : '';
        $product = $this->get_product();

        if ( ! $product || ! $attribute ) {
            echo esc_html( $settings['empty_fallback'] ?? '' );
            return;
        }

        $value = $this->get_attribute_value( $product, $attribute );

        if ( '' === $value ) {
            echo esc_html( $settings['empty_fallback'] ?? '' );
            return;
        }

        $output = '';
        if ( ! empty( $settings['prefix'] ) ) {
            $output .= $settings['prefix'];
        }

        if ( ! empty( $settings['show_label'] ) && 'yes' === $settings['show_label'] ) {
            $output .= $this->get_attribute_label( $attribute ) . ( $settings['separator'] ?? ': ' );
        }

        $output .= $value;

        if ( ! empty( $settings['suffix'] ) ) {
            $output .= $settings['suffix'];
        }

        echo wp_kses_post( $output );
    }
}
