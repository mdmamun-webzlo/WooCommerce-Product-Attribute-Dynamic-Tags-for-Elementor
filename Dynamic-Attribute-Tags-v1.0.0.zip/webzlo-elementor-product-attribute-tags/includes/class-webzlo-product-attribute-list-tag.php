<?php
if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Core\DynamicTags\Tag;

class Webzlo_Product_Attribute_List_Tag extends Tag {

    public function get_name() { return 'webzlo-product-attribute-list'; }
    public function get_title() { return esc_html__( 'Product Attribute List', 'webzlo-epa-tags' ); }
    public function get_group() { return 'webzlo-woocommerce-attributes'; }
    public function get_categories() { return [ \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY ]; }

    protected function register_controls() {
        $this->add_control( 'attributes', [
            'label' => esc_html__( 'Attributes', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::TEXTAREA,
            'description' => esc_html__( 'One attribute slug per line. Example: pa_brand, pad.plotis, pad.aukštis', 'webzlo-epa-tags' ),
            'default' => "pad.plotis\npad.aukštis\npad.diametras\nseason\nkuras\ntriukšmas",
        ] );

        $this->add_control( 'show_label', [
            'label' => esc_html__( 'Show Labels', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'yes',
        ] );

        $this->add_control( 'item_separator', [
            'label' => esc_html__( 'Item Separator', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::TEXT,
            'default' => ' · ',
        ] );

        $this->add_control( 'label_separator', [
            'label' => esc_html__( 'Label Separator', 'webzlo-epa-tags' ),
            'type' => Controls_Manager::TEXT,
            'default' => ': ',
        ] );
    }

    private function get_product() {
        global $product;
        if ( $product instanceof WC_Product ) return $product;
        return get_the_ID() ? wc_get_product( get_the_ID() ) : false;
    }

    private function get_value( $product, $key ) {
        $key = trim( $key );
        $value = $product->get_attribute( $key );
        if ( '' === $value ) $value = $product->get_attribute( sanitize_title( $key ) );
        if ( '' === $value ) {
            foreach ( [ $key, sanitize_title( $key ), '_' . $key, '_' . sanitize_title( $key ) ] as $meta_key ) {
                $meta = get_post_meta( $product->get_id(), $meta_key, true );
                if ( '' !== $meta && null !== $meta ) {
                    return is_array( $meta ) ? implode( ', ', array_filter( $meta ) ) : (string) $meta;
                }
            }
        }
        return (string) $value;
    }

    private function get_label( $key ) {
        $key = trim( $key );
        return taxonomy_exists( $key ) ? wc_attribute_label( $key ) : $key;
    }

    public function render() {
        $settings = $this->get_settings();
        $product = $this->get_product();
        if ( ! $product ) return;

        $attributes = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $settings['attributes'] ?? '' ) ) );
        $items = [];

        foreach ( $attributes as $attr ) {
            $value = wp_strip_all_tags( $this->get_value( $product, $attr ) );
            if ( '' === $value ) continue;
            $text = '';
            if ( ! empty( $settings['show_label'] ) && 'yes' === $settings['show_label'] ) {
                $text .= $this->get_label( $attr ) . ( $settings['label_separator'] ?? ': ' );
            }
            $text .= $value;
            $items[] = esc_html( $text );
        }

        echo implode( esc_html( $settings['item_separator'] ?? ' · ' ), $items );
    }
}
